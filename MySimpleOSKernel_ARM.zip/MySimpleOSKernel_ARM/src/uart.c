#include "include/uart.h"

#define UART0_BASE 0x20201000

#define UART0_DR    ((volatile unsigned int*)(UART0_BASE + 0x00))
#define UART_0_FR   ((volatile unsigned int*)(UART0_BASE + 0x18))

void uart_init() {
    //UART INIT FOR CODE SPECIFIC TO RASPBERRY PI.
}

void uart_putc(unsigned char c) {
    // WAIT FOR UART TO BE READY
    while (*UART0_FR & (1 << 5));
    *UART0_DR = c;
}

unsigned char uart_getc() {
    //WAIT FOR UART TO RECIEVE ANYTHING
    while (*UART0_FR & (1 << 4));
    return (unsigned char)(*UART0_DR);
}

void uart_puts(const char* str) {
    while (*str) {
        uart_putc(*str++);
    }
}
